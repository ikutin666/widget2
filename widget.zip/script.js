
function add_filter()
{
$($('.button-input__context-menu__item__inner')[6]).after('<li class="button-input__context-menu__item  element__ context-menu__item js-sort__item"> <div class="button-input__context-menu__item__inner"><span id="custom_filter" class="button-input__context-menu__item__text  ">Скрыть пустые этапы</span></div><li>')
$('#custom_filter').on('click', function()
{
	$($('.pipeline_status.pipeline_cell').children('div[id^="pipeline_items__list_"]')).each(function(index,value)
	{
		if($(value).children().length==0)
		{
			$(value).parent().css('display','none')
		}
	}


)
});


}

define(['jquery'], function($){
    var CustomWidget = function () {
    	var self = this;
		this.callbacks = {
			render: function(){
				console.log('render');
				return true;
			},
			init: function(){
				console.log('init');
				return true;
			},
			bind_actions: function(){
				console.log('bind_');
				add_filter();
				return true;
			},
			settings: function(){
				return true;
			},
			onSave: function(){
				alert('click');
				return true;
			},
			destroy: function(){
				
			},
			contacts: {
					//select contacts in list and clicked on widget name
					selected: function(){
						console.log('contacts');
					}
				},
			leads: {
					//select leads in list and clicked on widget name
					selected: function(){
						console.log('leads');
					}
				},
			tasks: {
					//select taks in list and clicked on widget name
					selected: function(){
						console.log('tasks');
					}
				}
		};
		return this;
    };

return CustomWidget;
});